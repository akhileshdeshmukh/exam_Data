const express=require("express");
const mysql =require("mysql");
const app=express();
const connection=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"manager",
    database:"mean"
});
connection.connect();
app.get("/",function(req,res){
    connection.query(`select * from tbl_vehicle`,function(err,result){
        if(err==null)
        {
res.contentType("application/json");
res.send(JSON.stringify(result));
        }else
        {
            res.contentType("application/json");
            res.send(JSON.stringify(err));
        }
    });
});

app.put("/:No",function(req,res){
    let vno=parseInt(req.params.No);
    let vname=req.body.vehiclename;
    let c=req.body.company;
    let t=req.body.type;
    let p=req.body.price;
    let d=req.body.description;
    let query=`update tbl_vehicle set vehiclename='${vname}',company='${c}',type='${t}',price='${p}',description='${d}' where vehicleno=${vno}`

    connection.query(query,function(err,result){
        if(err==null)
        {
res.contentType("application/json");
res.send(JSON.stringify(result));
        }else
        {
            res.contentType("application/json");
            res.send(JSON.stringify(err));
        }
    });
});
module.exports=app;