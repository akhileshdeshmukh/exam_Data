import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public http:HttpClient) { }
getdata()
{
  //return this.http.get("http://localhost:3537/vehicle/");
}
}
