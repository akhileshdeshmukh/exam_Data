import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import { RouterClintModule } from '@angular/common/Router';

import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { VehicleComponent } from './vehicle/vehicle.component';
import { HttpClient } from 'selenium-webdriver/http';
import { NfComponent } from './nf/nf.component';

@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    VehicleComponent,
    NfComponent
  ],
  imports: [
    BrowserModule,
    //HttpClient,
    //RouterClintModule:ForRouter[
    //{}
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
