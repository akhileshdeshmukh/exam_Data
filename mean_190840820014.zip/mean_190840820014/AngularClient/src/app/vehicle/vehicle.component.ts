import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {
  public ver;
  constructor(public service:DataService) { 
  }
  ngOnInit() {
    
    let iscome= this.service.getdata();
  }
}
//     iscome.subcribe((result)=>{
// if(result==null)
// {

// }else
// {
//   //ver=result;
// }
//     });
//   }
