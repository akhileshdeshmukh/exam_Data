import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nf',
  templateUrl: './nf.component.html',
  styleUrls: ['./nf.component.css']
})
export class NfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
