#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

typedef struct student
{
int roll,age;
char name[20];
}stud;

void accept();
void display(stud *t);
void wrd();
void rd();
void up();

int main()
{
int ch;
stud t;

while(1)
{
printf("\n1 write\n2 read\n3 update\n");
printf("enter your choice");
scanf("%d",&ch);

switch(ch)
{
	case 1: wrd();
					break;
	case 2: rd();
					break;
	case 3: up();
					break;
	default :_exit(0);

}
}
return 0;
}



void accept(stud *t)
{
printf("\n enter roll_no name and age ");
scanf("%d%s%d",&t->roll,t->name,&t->age);
}

void display(stud *t)
{
printf("roll no = %d\tname = %s\tage = %d\n",t->roll,t->name,t->age);
}


void rd()
{
stud t;
int fd=open("stud.db",O_RDONLY);
if(fd==-1)
{
perror("file is not open");
_exit(1);
}
while(read(fd,&t,sizeof(stud)) > 0)
{
display(&t);
}
close(fd);
}



void wrd()
{
stud t;
int fd= open("stud.db",O_CREAT|O_RDWR|O_APPEND,0644);
if(fd==-1)
{
perror("file is not open or create");
_exit(1);
}
accept(&t);
write(fd,&t,sizeof(stud));
		close(fd);
}


void up()
{
stud t;
long int o=sizeof(stud);
int fd= open("stud.db",O_RDWR);
int roll;
printf("enter roll no you want to update");
scanf("%d",&roll);


if(fd==-1)
{
perror("file is not open or create");
_exit(1);
}
while(read(fd,&t,sizeof(stud))>0)
{
if(t.roll==roll)
{
	lseek(fd,-o,SEEK_CUR);
accept(&t);
write(fd,&t,sizeof(stud));
}
}
close(fd);
}

