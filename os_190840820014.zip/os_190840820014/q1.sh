#!/bin/bash
clear
echo "$1"
if [ $1 -lt 10 ]
then 
echo "number is not palindrome"
fi
if [ $1 -gt 1000 -a $1 -lt 10000 ]
then
a=`expr $1 / 1000`
b=`expr $1 % 10`
c=`expr $1 / 100`
c=`expr $c % 10`
d=`expr $1 / 10`
d=`expr $1 % 10`
if [ $a -eq $b -a $c -eq $d ]
then
echo "number is palindrome"
else
echo "number is not  palindrome"
fi
fi

if [ $1 -gt 100 -a $1 -lt 1000 ]
then
#a=`expr $1 / 1000`
b=`expr $1 % 10`
c=`expr $1 / 100`
#c=`expr $c % 10`
#d=`expr $1 / 10`
#d=`expr $1 % 10`
if [ $b -eq $c ]
then
echo "number is palindrome"
else
echo "number is not  palindrome"
fi
fi


if [ $1 -gt 10 -a $1 -lt 100 ]
then

b=`expr $1 % 10`
d=`expr $1 / 10`
if [ $b -eq $d ]
then
echo "number is palindrome"
else
echo "number is not  palindrome"
fi
fi
exit
